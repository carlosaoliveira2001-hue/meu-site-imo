import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { PropertyCard } from "@/components/property-card"
import { MapPin, Maximize, Bed, Bath, Car, MessageCircle, ChevronLeft } from "lucide-react"
import { ImageGallery } from "@/components/image-gallery"
import { ShareButton } from "@/components/share-button"
import { FavoriteButton } from "@/components/favorite-button"
import { translations } from "@/lib/i18n/translations"
import { getProperty, getProperties } from "@/lib/properties-queries"
import { convertPropertyForDisplay, formatPrice } from "@/lib/properties-helpers"

interface PropertyPageProps {
  params: Promise<{
    id: string
  }>
}

export default async function PropertyPage({ params }: PropertyPageProps) {
  const { id } = await params
  const locale = "pt" // Default to Portuguese, can be made dynamic later

  const { property: dbProperty } = await getProperty(id)

  if (!dbProperty) {
    notFound()
  }

  const property = convertPropertyForDisplay(dbProperty)

  const { properties: allProperties } = await getProperties()
  const similarProperties = allProperties
    .filter((p) => p.id !== id && p.tipo === property.tipo && p.cidade === property.cidade)
    .slice(0, 3)
    .map(convertPropertyForDisplay)

  const t = translations[locale]

  const propertyTypeLabels = {
    casa: t.propertyTypes.house,
    apartamento: t.propertyTypes.apartment,
    terreno: t.propertyTypes.land,
  }

  const whatsappMessage = `${t.whatsappInterest} ${property.titulo[locale]} - ${formatPrice(property.preco)}`
  const whatsappUrl = `https://wa.me/351938390075?text=${encodeURIComponent(whatsappMessage)}`

  return (
    <div className="min-h-screen bg-background">
      {/* Back Button */}
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <Button asChild variant="ghost" className="gap-2">
            <Link href="/imoveis">
              <ChevronLeft className="h-4 w-4" />
              {t.backToProperties}
            </Link>
          </Button>
        </div>
      </div>

      <ImageGallery images={property.fotos} title={property.titulo[locale]} />

      {/* Property Details */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Header */}
            <div>
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex-1">
                  <Badge className="mb-3 bg-secondary text-secondary-foreground">
                    {propertyTypeLabels[property.tipo]}
                  </Badge>
                  <h1 className="text-3xl md:text-4xl font-bold text-balance mb-3">{property.titulo[locale]}</h1>
                  <div className="flex items-center text-muted-foreground gap-2">
                    <MapPin className="h-5 w-5 flex-shrink-0" />
                    <span className="text-lg">
                      {property.bairro}, {property.cidade}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <ShareButton />
                  <FavoriteButton />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary">{formatPrice(property.preco)}</div>
            </div>

            {/* Features */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">{t.features}</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="flex flex-col items-center text-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                      <Maximize className="h-6 w-6" />
                    </div>
                    <div>
                      <div className="font-semibold text-lg">{property.area}m²</div>
                      <div className="text-sm text-muted-foreground">{t.totalArea}</div>
                    </div>
                  </div>
                  {property.quartos && (
                    <div className="flex flex-col items-center text-center gap-2">
                      <div className="w-12 h-12 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                        <Bed className="h-6 w-6" />
                      </div>
                      <div>
                        <div className="font-semibold text-lg">{property.quartos}</div>
                        <div className="text-sm text-muted-foreground">{t.bedrooms}</div>
                      </div>
                    </div>
                  )}
                  {property.banheiros && (
                    <div className="flex flex-col items-center text-center gap-2">
                      <div className="w-12 h-12 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                        <Bath className="h-6 w-6" />
                      </div>
                      <div>
                        <div className="font-semibold text-lg">{property.banheiros}</div>
                        <div className="text-sm text-muted-foreground">{t.bathrooms}</div>
                      </div>
                    </div>
                  )}
                  {property.vagas && (
                    <div className="flex flex-col items-center text-center gap-2">
                      <div className="w-12 h-12 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center">
                        <Car className="h-6 w-6" />
                      </div>
                      <div>
                        <div className="font-semibold text-lg">{property.vagas}</div>
                        <div className="text-sm text-muted-foreground">{t.parkingSpaces}</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">{t.description}</h2>
                <p className="text-muted-foreground leading-relaxed">{property.descricao[locale]}</p>
              </CardContent>
            </Card>

            {/* Video Tour */}
            {property.videoUrl && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">{t.virtualTour}</h2>
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                      src={property.videoUrl}
                      title={t.virtualTour}
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Map */}
            {property.mapa && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">{t.location}</h2>
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                      src={property.mapa}
                      title={t.location}
                      className="w-full h-full"
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              {/* Contact Card */}
              <Card>
                <CardContent className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">{t.interested}</h2>
                  <p className="text-muted-foreground leading-relaxed">{t.interestedDescription}</p>
                  <Button asChild className="w-full gap-2" size="lg">
                    <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                      <MessageCircle className="h-5 w-5" />
                      {t.talkOnWhatsApp}
                    </a>
                  </Button>
                  <Button asChild variant="outline" className="w-full bg-transparent" size="lg">
                    <Link href="/contato">{t.sendMessage}</Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Property Info */}
              <Card>
                <CardContent className="p-6 space-y-3">
                  <h3 className="font-semibold">{t.propertyInfo}</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.code}:</span>
                      <span className="font-medium">#{property.id.slice(0, 8)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.type}:</span>
                      <span className="font-medium">{propertyTypeLabels[property.tipo]}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.city}:</span>
                      <span className="font-medium">{property.cidade}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{t.neighborhood}:</span>
                      <span className="font-medium">{property.bairro}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Similar Properties */}
        {similarProperties.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl md:text-3xl font-bold mb-8 text-balance">{t.similarProperties}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarProperties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
