"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Loader2, Upload, X, ImageIcon } from "lucide-react"
import { fetchPropertyForAdmin } from "@/lib/admin-actions"
import { addPropertyImage, deletePropertyImage } from "@/lib/properties-actions"
import { Card } from "@/components/ui/card"

interface ImageUploadSectionProps {
  propertyId: string
}

export function ImageUploadSection({ propertyId }: ImageUploadSectionProps) {
  const [images, setImages] = useState<any[]>([])
  const [uploading, setUploading] = useState(false)
  const [loading, setLoading] = useState(true)

  const loadImages = async () => {
    setLoading(true)
    const { property } = await fetchPropertyForAdmin(propertyId)
    if (property?.property_images) {
      setImages(property.property_images.sort((a: any, b: any) => a.order_index - b.order_index))
    }
    setLoading(false)
  }

  useEffect(() => {
    loadImages()
  }, [propertyId])

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)

    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      const formData = new FormData()
      formData.append("file", file)

      try {
        // Upload to Blob storage
        const uploadResponse = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        })

        const uploadData = await uploadResponse.json()

        if (uploadData.url) {
          // Add image to database
          const orderIndex = images.length + i
          await addPropertyImage(propertyId, uploadData.url, orderIndex)
        }
      } catch (error) {
        console.error("[v0] Error uploading image:", error)
      }
    }

    await loadImages()
    setUploading(false)

    // Reset input
    e.target.value = ""
  }

  const handleDeleteImage = async (imageId: string, imageUrl: string) => {
    try {
      // Delete from Blob storage
      await fetch("/api/delete-image", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: imageUrl }),
      })

      // Delete from database
      await deletePropertyImage(imageId, propertyId)

      await loadImages()
    } catch (error) {
      console.error("[v0] Error deleting image:", error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div>
        <Label>Imagens do Imóvel</Label>
        <p className="text-sm text-muted-foreground">Adicione fotos do imóvel. A primeira imagem será a capa.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {images.map((image, index) => (
          <Card key={image.id} className="relative overflow-hidden">
            <div className="aspect-video relative">
              <img
                src={image.image_url || "/placeholder.svg"}
                alt={`Imagem ${index + 1}`}
                className="h-full w-full object-cover"
              />
              <Button
                variant="destructive"
                size="icon"
                className="absolute right-2 top-2"
                onClick={() => handleDeleteImage(image.id, image.image_url)}
              >
                <X className="h-4 w-4" />
              </Button>
              {index === 0 && (
                <div className="absolute bottom-2 left-2 rounded bg-primary px-2 py-1 text-xs text-primary-foreground">
                  Capa
                </div>
              )}
            </div>
          </Card>
        ))}

        <Card className="flex aspect-video items-center justify-center border-2 border-dashed">
          <Label htmlFor="image-upload" className="flex cursor-pointer flex-col items-center gap-2 p-4">
            {uploading ? (
              <>
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                <span className="text-sm text-muted-foreground">A carregar...</span>
              </>
            ) : (
              <>
                <Upload className="h-8 w-8 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Adicionar Imagens</span>
              </>
            )}
            <Input
              id="image-upload"
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleFileUpload}
              disabled={uploading}
            />
          </Label>
        </Card>
      </div>

      {images.length === 0 && (
        <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 text-center">
          <ImageIcon className="mb-4 h-12 w-12 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Nenhuma imagem adicionada ainda.</p>
          <p className="text-xs text-muted-foreground">Clique no botão acima para adicionar imagens.</p>
        </div>
      )}
    </div>
  )
}
