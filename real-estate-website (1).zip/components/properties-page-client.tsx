"use client"

import { useState, useMemo } from "react"
import { PropertyCard } from "@/components/property-card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { formatPrice } from "@/lib/properties-helpers"
import { SlidersHorizontal, X } from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import type { PropertyForDisplay } from "@/lib/properties-helpers"

interface PropertiesPageClientProps {
  properties: PropertyForDisplay[]
}

export function PropertiesPageClient({ properties }: PropertiesPageClientProps) {
  const [tipo, setTipo] = useState<string>("todos")
  const [cidade, setCidade] = useState<string>("todas")
  const [precoMax, setPrecoMax] = useState<number>(3000000)
  const [areaMin, setAreaMin] = useState<number>(0)
  const [quartos, setQuartos] = useState<string>("todos")

  // Get unique cities from properties
  const cidades = useMemo(() => {
    const uniqueCities = Array.from(new Set(properties.map((p) => p.cidade))).sort()
    return uniqueCities
  }, [properties])

  // Filter properties based on selected filters
  const filteredProperties = useMemo(() => {
    return properties.filter((property) => {
      if (tipo !== "todos" && property.tipo !== tipo) return false
      if (cidade !== "todas" && property.cidade !== cidade) return false
      if (property.preco > precoMax) return false
      if (property.area < areaMin) return false
      if (quartos !== "todos") {
        const quartosNum = Number.parseInt(quartos)
        if (!property.quartos || property.quartos < quartosNum) return false
      }
      return true
    })
  }, [properties, tipo, cidade, precoMax, areaMin, quartos])

  const resetFilters = () => {
    setTipo("todos")
    setCidade("todas")
    setPrecoMax(3000000)
    setAreaMin(0)
    setQuartos("todos")
  }

  const hasActiveFilters =
    tipo !== "todos" || cidade !== "todas" || precoMax !== 3000000 || areaMin !== 0 || quartos !== "todos"

  const FilterContent = () => (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="tipo">Tipo de Imóvel</Label>
        <Select value={tipo} onValueChange={setTipo}>
          <SelectTrigger id="tipo">
            <SelectValue placeholder="Selecione o tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="casa">Casa</SelectItem>
            <SelectItem value="apartamento">Apartamento</SelectItem>
            <SelectItem value="terreno">Terreno</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="cidade">Cidade</Label>
        <Select value={cidade} onValueChange={setCidade}>
          <SelectTrigger id="cidade">
            <SelectValue placeholder="Selecione a cidade" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas</SelectItem>
            {cidades.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="quartos">Quartos</Label>
        <Select value={quartos} onValueChange={setQuartos}>
          <SelectTrigger id="quartos">
            <SelectValue placeholder="Número de quartos" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="1">1+</SelectItem>
            <SelectItem value="2">2+</SelectItem>
            <SelectItem value="3">3+</SelectItem>
            <SelectItem value="4">4+</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        <Label htmlFor="preco">Preço Máximo: {formatPrice(precoMax)}</Label>
        <Slider
          id="preco"
          min={100000}
          max={3000000}
          step={50000}
          value={[precoMax]}
          onValueChange={(value) => setPrecoMax(value[0])}
          className="w-full"
        />
      </div>

      <div className="space-y-3">
        <Label htmlFor="area">Área Mínima: {areaMin}m²</Label>
        <Slider
          id="area"
          min={0}
          max={500}
          step={10}
          value={[areaMin]}
          onValueChange={(value) => setAreaMin(value[0])}
          className="w-full"
        />
      </div>

      {hasActiveFilters && (
        <Button onClick={resetFilters} variant="outline" className="w-full gap-2 bg-transparent">
          <X className="h-4 w-4" />
          Limpar Filtros
        </Button>
      )}
    </div>
  )

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-balance mb-2">Todos os Imóveis</h1>
          <p className="text-lg text-primary-foreground/90 text-pretty leading-relaxed">
            Encontre o imóvel perfeito para você
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Desktop Filters Sidebar */}
          <aside className="hidden lg:block w-80 flex-shrink-0">
            <div className="sticky top-8 bg-card border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-6">Filtros</h2>
              <FilterContent />
            </div>
          </aside>

          {/* Mobile Filters */}
          <div className="lg:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full gap-2 bg-transparent">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filtros
                  {hasActiveFilters && (
                    <span className="ml-auto bg-primary text-primary-foreground rounded-full px-2 py-0.5 text-xs">
                      Ativos
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <SheetHeader>
                  <SheetTitle>Filtros</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Properties Grid */}
          <div className="flex-1">
            <div className="mb-6">
              <p className="text-muted-foreground">
                {filteredProperties.length}{" "}
                {filteredProperties.length === 1 ? "imóvel encontrado" : "imóveis encontrados"}
              </p>
            </div>

            {filteredProperties.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredProperties.map((property) => (
                  <PropertyCard key={property.id} property={property} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-xl text-muted-foreground mb-4">
                  Nenhum imóvel encontrado com os filtros selecionados
                </p>
                <Button onClick={resetFilters} variant="outline">
                  Limpar Filtros
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
