// Helper functions to convert database properties to the format expected by components

export interface PropertyFromDB {
  id: string
  tipo: "casa" | "apartamento" | "terreno"
  titulo_pt: string
  titulo_en: string
  preco: number
  area: number
  quartos?: number
  banheiros?: number
  vagas?: number
  cidade: string
  bairro: string
  descricao_pt: string
  descricao_en: string
  video_url?: string
  mapa?: string
  destaque: boolean
  property_images?: Array<{
    id: string
    image_url: string
    order_index: number
  }>
}

export interface PropertyForDisplay {
  id: string
  tipo: "casa" | "apartamento" | "terreno"
  titulo: { pt: string; en: string }
  preco: number
  area: number
  quartos?: number
  banheiros?: number
  vagas?: number
  cidade: string
  bairro: string
  descricao: { pt: string; en: string }
  fotos: string[]
  videoUrl?: string
  mapa?: string
  destaque: boolean
}

export function convertPropertyForDisplay(dbProperty: PropertyFromDB): PropertyForDisplay {
  return {
    id: dbProperty.id,
    tipo: dbProperty.tipo,
    titulo: {
      pt: dbProperty.titulo_pt,
      en: dbProperty.titulo_en,
    },
    preco: dbProperty.preco,
    area: dbProperty.area,
    quartos: dbProperty.quartos,
    banheiros: dbProperty.banheiros,
    vagas: dbProperty.vagas,
    cidade: dbProperty.cidade,
    bairro: dbProperty.bairro,
    descricao: {
      pt: dbProperty.descricao_pt,
      en: dbProperty.descricao_en,
    },
    fotos: dbProperty.property_images?.sort((a, b) => a.order_index - b.order_index).map((img) => img.image_url) || [],
    videoUrl: dbProperty.video_url,
    mapa: dbProperty.mapa,
    destaque: dbProperty.destaque,
  }
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat("pt-PT", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price)
}
