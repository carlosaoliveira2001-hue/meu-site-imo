import { createClient } from "@/lib/supabase/server"
import { properties as staticProperties } from "@/lib/properties-data"

function convertStaticToDbFormat(property: any) {
  return {
    id: property.id,
    tipo: property.tipo,
    titulo_pt: property.titulo.pt,
    titulo_en: property.titulo.en,
    preco: property.preco,
    area: property.area,
    quartos: property.quartos,
    banheiros: property.banheiros,
    vagas: property.vagas,
    cidade: property.cidade,
    bairro: property.bairro,
    descricao_pt: property.descricao.pt,
    descricao_en: property.descricao.en,
    video_url: property.videoUrl,
    mapa: property.mapa,
    destaque: property.destaque || false,
    property_images:
      property.fotos?.map((url: string, index: number) => ({
        id: `${property.id}-img-${index}`,
        url,
        ordem: index,
      })) || [],
  }
}

export async function getProperties() {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase
      .from("properties")
      .select("*, property_images(*)")
      .order("created_at", { ascending: false })

    if (error && error.code === "PGRST205") {
      console.log("[v0] Database not ready, using static data as fallback")
      return {
        properties: staticProperties.map(convertStaticToDbFormat),
        error: null,
        usingFallback: true,
      }
    }

    if (error) {
      console.error("[v0] Error fetching properties:", error)
      return {
        properties: staticProperties.map(convertStaticToDbFormat),
        error: null,
        usingFallback: true,
      }
    }

    return { properties: data || [], error: null, usingFallback: false }
  } catch (err) {
    console.log("[v0] Database error, using static data as fallback")
    return {
      properties: staticProperties.map(convertStaticToDbFormat),
      error: null,
      usingFallback: true,
    }
  }
}

export async function getProperty(id: string) {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase.from("properties").select("*, property_images(*)").eq("id", id).single()

    if (error && error.code === "PGRST205") {
      console.log("[v0] Database not ready, using static data as fallback")
      const staticProperty = staticProperties.find((p) => p.id === id)
      if (staticProperty) {
        return {
          property: convertStaticToDbFormat(staticProperty),
          error: null,
          usingFallback: true,
        }
      }
      return { property: null, error: "Property not found", usingFallback: true }
    }

    if (error) {
      console.error("[v0] Error fetching property:", error)
      const staticProperty = staticProperties.find((p) => p.id === id)
      if (staticProperty) {
        return {
          property: convertStaticToDbFormat(staticProperty),
          error: null,
          usingFallback: true,
        }
      }
      return { property: null, error: "Property not found", usingFallback: true }
    }

    return { property: data, error: null, usingFallback: false }
  } catch (err) {
    console.log("[v0] Database error, using static data as fallback")
    const staticProperty = staticProperties.find((p) => p.id === id)
    if (staticProperty) {
      return {
        property: convertStaticToDbFormat(staticProperty),
        error: null,
        usingFallback: true,
      }
    }
    return { property: null, error: "Property not found", usingFallback: true }
  }
}
